from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from check_docs import check_project


class CheckDocsTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.project = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def write(self, relative_path: str, content: str) -> None:
        path = self.project / relative_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def codes(self, report: dict[str, object]) -> list[str]:
        return [str(item["code"]) for item in report["issues"]]

    def test_valid_project(self) -> None:
        self.write(
            "Architecture/README.md",
            "# Architecture\n\n[目标](目标.md#处理器目标)\n",
        )
        self.write("Architecture/目标.md", "# 处理器目标\n\n支持可验证执行。\n")
        self.write("Design/README.md", "# Design\n\n[概述](概述.md)\n")
        self.write("Design/概述.md", "# 概述\n\n描述当前设计。\n")
        self.write(
            "Verification/README.md",
            "# Verification\n\n[计划](计划.md)\n",
        )
        self.write("Verification/计划.md", "# 计划\n\n检查目标性质。\n")

        report = check_project(self.project)

        self.assertTrue(report["ok"], report["issues"])
        self.assertEqual(report["filesChecked"], 6)
        self.assertIn(
            "Architecture/目标.md",
            [item["path"] for item in report["measurements"]],
        )

    def test_research_root_is_discovered(self) -> None:
        self.write("Research/README.md", "# Research\n\n[调研](调研.md)\n")
        self.write("Research/调研.md", "# 调研\n\n记录来源化证据。\n")

        report = check_project(self.project)

        self.assertTrue(report["ok"], report["issues"])
        self.assertEqual(report["roots"], ["Research"])
        profiles = {item["profile"] for item in report["measurements"]}
        self.assertEqual(profiles, {"readme", "research"})

    def test_finding_uses_short_budget(self) -> None:
        self.write(
            "Research/README.md",
            "# Research\n\n[Finding](findings/F_001.md)\n",
        )
        self.write("Research/findings/F_001.md", "# Finding\n\n" + ("x" * 4001))

        report = check_project(self.project)
        measurement = next(
            item
            for item in report["measurements"]
            if item["path"] == "Research/findings/F_001.md"
        )

        self.assertEqual(measurement["profile"], "finding")
        self.assertIn("effective_chars_exceeded", self.codes(report))

    def test_cli_emits_utf8_paths(self) -> None:
        self.write("Design/README.md", "# Design\n\n[协议](协议.md)\n")
        self.write("Design/协议.md", "# 协议\n")
        script = Path(__file__).with_name("check_docs.py")

        completed = subprocess.run(
            [sys.executable, "-B", str(script), str(self.project), "--json"],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertIn("协议.md", completed.stdout.decode("utf-8"))

    def test_reports_length_and_missing_anchor(self) -> None:
        self.write(
            "Architecture/README.md",
            "# Architecture\n\n[目标](目标.md#不存在)\n",
        )
        self.write("Architecture/目标.md", "# 目标\n\n" + ("字" * 10001))

        report = check_project(self.project)
        codes = self.codes(report)

        self.assertIn("broken_anchor", codes)
        self.assertIn("effective_chars_exceeded", codes)

    def test_reports_broken_link_and_orphan(self) -> None:
        self.write(
            "Design/README.md",
            "# Design\n\n[缺失](missing.md)\n",
        )
        self.write("Design/orphan.md", "# Orphan\n")

        report = check_project(self.project)
        codes = self.codes(report)

        self.assertIn("broken_link", codes)
        self.assertIn("orphan_document", codes)

    def test_reports_conflict_and_duplicate_tree(self) -> None:
        self.write(
            "Design/README.md",
            "# Design\n\n[旧树](FinalDesign/current.md)\n\n"
            "[备份](ZJRDesignBackup/backup.md)\n\n"
            "[旧目录](old queue/old.md)\n",
        )
        self.write(
            "Design/FinalDesign/current.md",
            "# Current\n\n<<<<<<< ours\ntext\n>>>>>>> theirs\n",
        )
        self.write("Design/ZJRDesignBackup/backup.md", "# Backup\n")
        self.write("Design/old queue/old.md", "# Old\n")

        report = check_project(self.project)
        codes = self.codes(report)

        self.assertIn("conflict_marker", codes)
        self.assertIn("duplicate_current_tree", codes)
        self.assertEqual(codes.count("duplicate_current_tree"), 3)

    def test_rendered_diagram_requires_editable_source(self) -> None:
        self.write("Design/README.md", "# Design\n\n[概述](overview.md)\n")
        self.write(
            "Design/overview.md",
            "# Overview\n\n![拓扑](pics/topology.png)\n",
        )
        self.write("Design/pics/topology.png", "not-a-real-image")

        missing_source = check_project(self.project)
        self.assertIn(
            "missing_editable_diagram_source", self.codes(missing_source)
        )

        self.write("Design/pics/topology.drawio", "<mxfile />")
        with_source = check_project(self.project)
        self.assertTrue(with_source["ok"], with_source["issues"])

    def test_verification_screenshot_does_not_require_editable_source(self) -> None:
        self.write(
            "Verification/README.md",
            "# Verification\n\n[结果](result.md)\n",
        )
        self.write(
            "Verification/result.md",
            "# Result\n\n![波形截图](evidence/wave.png)\n",
        )
        self.write("Verification/evidence/wave.png", "not-a-real-image")

        report = check_project(self.project)

        self.assertTrue(report["ok"], report["issues"])

    def test_reference_link_is_reachable(self) -> None:
        self.write(
            "Design/README.md",
            "# Design\n\n[概述][overview]\n\n[overview]: overview.md\n",
        )
        self.write("Design/overview.md", "# Overview\n")

        report = check_project(self.project)

        self.assertTrue(report["ok"], report["issues"])

    def test_reports_absolute_file_link(self) -> None:
        self.write(
            "Architecture/README.md",
            "# Architecture\n\n[外部](file:///tmp/outside.md)\n",
        )

        report = check_project(self.project)

        self.assertIn("absolute_local_link", self.codes(report))


if __name__ == "__main__":
    unittest.main()
