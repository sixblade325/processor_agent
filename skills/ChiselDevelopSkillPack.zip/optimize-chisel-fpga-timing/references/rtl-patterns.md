# Chisel FPGA Timing Patterns

Use these patterns only after closing the local cycle contract. Names are illustrative.

## 1. Register next-state availability

Use when a banked structure's current occupancy and a phase mux form a long `valid` or `ready` path.

Inside each bank, expose the next-state fact that already feeds the state register:

```scala
val noEmptyNext = WireDefault(noEmpty)

when(enqFire && !deqFire) {
  noEmptyNext := true.B
}
when(!enqFire && deqFire) {
  noEmptyNext := !deqRemovesLast
}

io.nextNoEmpty := noEmptyNext
noEmpty := noEmptyNext
```

At the outer level, compute the next port-to-bank mapping and register availability:

```scala
for (p <- 0 until deqWidth) {
  deqValidReg(p) := Mux1H(nextBankOH(p), banks.map(_.io.nextNoEmpty))
}

io.deq(p).valid := deqValidReg(p)
```

Required proof:

- `nextBankOH` is one-hot;
- registered `valid` describes the same bank selected for `bits` next cycle;
- flush initializes bank state and `deqValidReg` consistently;
- a standard `Decoupled` producer holds `valid` and `bits` stable while stalled.

If mapping rotates while `valid && !ready`, add a holding register or freeze the mapping. A specialized non-holding availability protocol must document that exception explicitly.

## 2. Register priority pairs from next-state

Use when age-wrap selection and `PriorityEncoderOH` are on the consumer path.

```scala
val nextEntries = WireDefault(entries)
// Apply alloc, wakeup, issue, release, and flush to nextEntries here.

val nextEligible = VecInit(nextEntries.map(entryEligible)).asUInt
val n = entries.length
val lowerMaskNext = (headOHNext - 1.U(n.W))(n - 1, 0)
val upperMaskNext = (~lowerMaskNext)(n - 1, 0)

val highOHNext = PriorityEncoderOH(nextEligible & upperMaskNext)
val lowOHNext  = PriorityEncoderOH(nextEligible & lowerMaskNext)

entries   := nextEntries
highOHReg := highOHNext
lowOHReg  := lowOHNext

val issueOH = Mux(highOHReg.orR, highOHReg, lowOHReg)
```

The entries and both priority results must latch on the same edge from the same next-state version. This preserves the first eligible issue cycle.

Registering only final `issueOH` can place eligibility, wrap selection, and both encoders on one D-input cone. Keeping the two encoder results separate leaves a small Q-side choice and can balance both sides.

For multiple lanes, form each lane's candidate mask in parallel. Avoid feeding one encoder's result into the next encoder when a disjoint partition or precomputed exclusion mask can express the policy.

## 3. Precompute one-hot age masks

For a one-hot head pointer:

```scala
val lowerThanHead = (headOH - 1.U(n.W))(n - 1, 0)
val atOrAfterHead = (~lowerThanHead)(n - 1, 0)
```

Register these masks one cycle before the issue tree when the head update contract allows it. Latch the masks and any selectors derived from them against the same head version.

## 4. Distribute pure work before selecting

When a pure transform is applied after a mux, test whether it can be distributed over the candidates:

```text
f(Mux(sel, a, b)) == Mux(sel, f(a), f(b))
```

This is useful when `f(a)` is narrower than `a`, or when `f` is expensive and otherwise sits serially after selector generation. The transform must have no state, side effects, candidate-specific valid behavior, or selector dependency.

When selecting one word from multiple cache lines, extract all candidate words in parallel and mux only the word:

```scala
val candidateWords = VecInit(lineData.map { line =>
  VecInit.tabulate(wordsPerLine)(w => line(32 * (w + 1) - 1, 32 * w))(wordIdx)
})

val loadWord = Mux1H(hitWayOH, candidateWords)
```

This replaces a wide way mux followed by a dynamic word mux with parallel local extraction plus a narrow way mux. Apply the same rule to Bundles: select an index first, then mux only fields consumed in that stage.

The same rewrite applies to comparisons. Instead of selecting a wide expected value and then comparing it:

```scala
val expected = Mux(taken, imm, 4.U(32.W))
val mismatch = predOffset =/= expected
```

compare both candidates in parallel and select the 1-bit results:

```scala
val takenMismatch = predOffset =/= imm
val fallThroughMismatch = predOffset =/= 4.U(32.W)
val mismatch = Mux(taken, takenMismatch, fallThroughMismatch)
```

This removes the wide mux and comparison from the selector-dependent chain. It can duplicate logic and increase shared-input fanout, so inspect emitted RTL first and use routed A/B evidence to decide whether the trade is beneficial.

If the remaining narrow mux is still on the limiting Q-to-consumer path, test a registered consumer view derived from the same next-state version:

```scala
val issueViewNext = Mux1H(issueOHNext, nextEntries.map(consumerView))

entries  := nextEntries
issueOH  := issueOHNext
issueView := issueViewNext
```

This preserves cycle alignment when all three values latch on the same edge. It moves selection into `issueView`'s D-input cone, so compare that new D path before accepting the change. Do not register a full entry when the consumer reads only a narrow view.

## 5. Capture a cross-module predicate locally

Use when a global compare feeds every candidate and then a wide arbitration tree.

```scala
for (i <- entries.indices) {
  when(entries(i).valid) {
    entries(i).robHeadReady := !entries(i).isSerializing ||
      sameRob(entries(i).robIdx, io.robHead)
  }
}

val eligible = entry.valid && entry.operandsReady && entry.robHeadReady
```

Required proof:

- the predicate may be observed one cycle late;
- a stale true cannot authorize an entry after ownership changes;
- the source state remains stable until the authorized entry issues;
- allocation, flush, and slot reuse initialize the local bit.

This pattern trades per-entry FF and D-side compares for a short local Q-to-arbitration path.

## 6. Manually map fixed dispatch widths

For widths such as two or three, precompute pointer rotations and mutually exclusive count classes:

```scala
val tail1 = rotateLeft(tailOH, 1)
val tail2 = rotateLeft(tailOH, 2)
val tail3 = rotateLeft(tailOH, 3)

val take0 = laneClass(0)
val take1 = laneClass(1)
val take2 = laneClass(2)

// Enumerate the accepted class combinations directly.
// Select tailOH, tail1, tail2, or tail3 with mutually exclusive terms.
```

This avoids dynamic shifts, generic `PopCount` arithmetic, and serial compaction. Keep each lane's allocation event gated by its own fire event. Assert that generated allocation OHs are disjoint.

## 7. Remove an admission-only valid gate

An invalid-lane class bit may be removed from a timing-critical admission cone only when all of these hold:

```text
the class result never directly writes state
all allocation and write events remain gated by laneFire and lane valid
invalid lanes cannot grant themselves or suppress a valid lane selectively
stale class bits can only create an accepted false stall
the user accepts that performance behavior
```

Typical structure:

```scala
val requestClassMask = rawClassBits
val batchReady = capacityAccepts(requestClassMask)

val laneFire = dispatchFire && lane.valid
val allocate = laneFire && rawClassBits(lane)
```

Add assertions tying every state mutation to `laneFire`. Test all invalid-lane class combinations, including stale high bits.

## 8. Use natural zero behavior and DCE

`PriorityEncoderOH(0.U)` produces zero. This wrapper adds redundant logic:

```scala
Mux(mask.orR, PriorityEncoderOH(mask), 0.U)
```

Use:

```scala
PriorityEncoderOH(mask)
```

For internal Bundles within one elaborated top, firtool removes fields, ports, and registers that do not reach a consumer. Keep semantic Bundles when they improve source clarity, then inspect emitted RTL. Top-level IO fields remain externally observable and cannot be assumed dead.

## 9. Assertions that support timing edits

```scala
assert(PopCount(selectOH) <= 1.U)
assert((writeOH & ~validMask) === 0.U)
assert((allocOH.reduce(_ | _) & releasedOH) === 0.U)
assert(!stateWrite || laneFire)
```

Assertions document the proof boundary. They do not repair an invalid protocol or compensate for misaligned registered data and control.

## 10. Patterns to challenge

- Serial `PriorityEncoderOH` chains for multi-port allocation.
- `PopCount` followed by dynamic rotate for width two or three.
- Whole-entry `Mux1H` when the stage reads only a few fields.
- A wide mux followed by a pure narrow transform that can be distributed across candidates.
- Replicated wide equality comparisons directly inside an issue tree.
- Registering a final selector without checking its D-input cone.
- `dontTouch` used to force speculative timing structure.
- A source-level six-input expression assumed to map to one LUT6 without netlist evidence.
- A register added to `ready` without checking `valid` and `bits` stability.
