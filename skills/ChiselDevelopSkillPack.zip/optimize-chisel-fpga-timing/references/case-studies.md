# Project-Derived Case Studies

These cases came from one LoongArch Chisel FPGA project. Reuse the reasoning pattern and remeasure every design.

## LDQ and STQ priority-pair registers

Initial structure latched a final issue selector after age partition and priority work. The D-input cone remained long. The revised structure latched the high-region and low-region `PriorityEncoderOH` results computed from the same `nextEntries` version, then selected between the two registered OH values on the Q side.

Observed in one routed comparison:

- D-input slack improved by about `0.554 ns`.
- Data path delay fell by about `0.337 ns`.
- Logic levels fell from 15 to 14.
- Q-output slack improved by about `1.113 ns`.
- The D and Q sides became balanced within about `0.066 ns`.
- Full-design cost increased by about 124 LUT and 30 FF.

Lesson: register smaller intermediate results when a final registered result overloads its D cone. Preserve the first issue cycle by deriving entries and selectors from the same next-state version.

## Banked free-list registered availability

The original port `valid` depended on current SubFIFO occupancy plus a rotating port-to-bank mux. Each SubFIFO exposed `nextNoEmpty`, and the outer free-list registered the availability of the bank mapped to each port for the next cycle.

Lesson: next-state facts can move bank occupancy and phase selection off the consumer path. Check standard `Decoupled` hold semantics and align `bits` to the same mapping.

## Dcache narrow-before-select

The load path selected a wide cache-line candidate and then selected one word. The optimized path extracted each candidate word in parallel and performed the final way selection on 32-bit values.

Lesson: crop or decode near each producer before a cross-way or cross-module mux. This reduces routed bus width as well as logical mux width.

## Branch compare-before-select

The branch prediction check selected either a 32-bit taken offset or the 32-bit fall-through offset, then compared the selected value with `predOffset`. The optimized form compared `predOffset` with both candidates in parallel and selected the two 1-bit mismatch results with `realJp`.

The Boolean rewrite is exact for two-state hardware values:

```text
predOffset != Mux(realJp, imm, 4)
  == Mux(realJp, predOffset != imm, predOffset != 4)
```

Emitted SystemVerilog confirmed that the wide mux moved out of the selector-dependent comparison chain. This proves the intended RTL topology, not a routed timing gain. The rewrite duplicates a comparison branch and increases `predOffset` fanout, so `CARRY4`, route delay, endpoint slack, resources, and global WNS still require a same-constraint routed A/B run.

Lesson: distribute a pure transform over mux candidates when it moves expensive work parallel to selector generation and leaves only a narrow result mux. Check duplicated logic and shared-input fanout before accepting it.

## MemIQ local ROB-head readiness

CACOP eligibility dynamically compared each entry's ROB identity with a global `robHead`, then fed candidate and age arbitration. A per-entry `robHeadReady` bit captured this predicate one cycle earlier. Issue arbitration consumed local Q outputs.

Lesson: replicate cheap D-side compares and store a local predicate when a global identity bus and comparator farm feed a critical issue tree. Prove that one-cycle delay and stale-true behavior are safe.

## Dispatch raw class masks

Load and Store class masks originally ANDed class bits with lane validity on an admission path. Queue and ROB mutations were already gated by `laneFire`. Removing validity from the class mask removed a small LUT level. Invalid-lane class bits could only create a false stall, which the design accepted as a performance effect.

One routed path showed a class-plus-valid LUT2 cell delay of about `0.125 ns`, while adjacent routes were around `1.007 ns` and `0.741 ns`.

Lesson: remove an admission-only gate only after tracing every state mutation. Also inspect route delay, since deleting a small LUT may leave physical routing as the dominant cost.

## Route-dominated cross-module path

One full path contained 15 LUT levels with about `2.121 ns` logic delay and `9.513 ns` route delay. A source-level encoder was visible in the cone, yet cross-module routing dominated the result.

Lesson: expose each timing level and route segment before assigning blame. Do not name a source primitive as the bottleneck from path membership alone.

## Demand-granular LSQ admission

Changing LDQ and STQ admission from a coarse batch threshold to registered low-contiguous capacity masks improved utilization and resource behavior. It also moved pressure to the Dispatch-to-LSQ maintenance path. The registered mask Q-to-ready cone was shallow, while generation and cross-module routing became the important paths.

Lesson: a better capacity policy can shift the bottleneck from admission output to next-state maintenance. Query both sides of the new register boundary.

## Reusable conclusions

1. Register an early fact only when it is available from next-state logic and cycle-aligned with its data.
2. Balance D-side and Q-side work instead of optimizing only the visible output.
3. Reduce width before long selection or routing.
4. Distribute pure transforms across mux candidates when this leaves only a narrow selector-dependent result.
5. Replace global live predicates with local registered facts when lifetime rules permit.
6. Remove admission-only conditions only after proving all state changes remain fire-gated.
7. Inspect emitted RTL for DCE and encoder behavior before paying for a full implementation run.
8. Treat routed path data as local evidence tied to one build configuration.
