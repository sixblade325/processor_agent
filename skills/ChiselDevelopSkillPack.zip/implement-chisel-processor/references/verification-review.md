# Verification And Review

## Primary verification

Use Verilator by default. Keep tests and logs in the module test directory. Record the exact command and random seed.

Cover applicable cases:

- normal completion and backpressure;
- empty, full, single-entry, and simultaneous-port states;
- same-cycle event conflicts and documented priority;
- flush, kill, late response, retry, and index reuse;
- one-hot, mask-subset, and mutual-exclusion assertions;
- narrow-address repeated reads and writes;
- same-cache-line ordering and cross-line concurrency;
- hit, miss-owned, miss-nack, forwarding full/partial coverage;
- allocation/merge conflicts, refill/install/writeback interactions;
- reset and long randomized stress with a reference model or scoreboard.

Use Treadle only when explicitly requested or for Verilator environment diagnosis. State the reason.

## Failure record

Record:

```text
测试名：
复现命令：
随机种子：
失败周期：
失败信号：
实际行为：
期望行为：
定位模块：
根因：
修复建议：
```

## Static-review subagent

Provide design paths, source paths, tests, and acceptance criteria. Ask it to return findings ordered by severity with file and line references. Require checks for:

- mismatch between target documents and implementation;
- redundant conditions, overprotection, or invented protocol;
- serial dependency chains, wide muxes, fanout, and ready/valid loops;
- event overlap, missing assertions, late responses, and index reuse;
- weak tests whose observed result cannot distinguish the intended behavior.

## Verification subagent

Provide source and test paths plus commands, without the primary agent's expected verdict. Require an independent run and a short report containing backend, seed, cycle count, pass/fail, log path, and uncovered behavior.

## Report naming

Follow repository convention, typically:

```text
test/<Module>/<Module>StaticReview.subagent.md
test/<Module>/<Module>Verification.subagent.md
```

After fixes, rerun every affected directed test and the relevant stress test. Preserve failure logs when they explain a resolved bug; ignore generated logs in Git when repository policy requires it.
