---
name: implement-chisel-processor
description: Document-driven workflow for implementing and modifying Chisel processor and memory-subsystem RTL. Use when Codex must work from user-maintained architecture/design documents, preserve user implementation notes and code fragments, maintain separate agent-authored implementation documentation, reason in synthesized-hardware terms, avoid redundant or overprotective logic, and complete independent static review plus Verilator validation through subagents.
---

# Implement Chisel Processor

## Establish authority

Read repository instructions first. Then locate and read, in order:

1. User-maintained architecture and design documents.
2. User-maintained module-local implementation document.
3. Current source, tests, generated reports, and relevant reference implementation.
4. Agent-maintained `<SourceBase>_codex.md` if present.

Treat design documents as target behavior and source as current behavior. Never silently resolve a conflict. State the target, current implementation, and required migration.

Do not modify user-owned design documents unless explicitly requested. Treat module-local documents without `_codex` as user-owned. Prefer their code fragments and naming. If a fragment has a syntax, type, timing, or semantic error, report the exact issue before changing its meaning.

## Close the design before coding

Trace every affected field with `rg`: producer, consumer, storage point, update event, and cycle boundary. Derive:

- field semantics and identity representation;
- allocation, wakeup, issue, response, settle, release, flush, kill, and retry events;
- same-cycle conflicts and explicit priority;
- late-response and index-reuse behavior;
- invariants and acceptance criteria.

Ask before adding a table-entry field, changing a cross-module protocol, or adding generation/tag protection. Do not invent unspecified protocols or conservative guards.

## Implement as hardware

Read [hardware-rules.md](references/hardware-rules.md) before writing RTL.

Make the smallest change that preserves the documented semantics. Reuse the repository's reference processor structure when requested. Keep event generation parallel and centralize state-update priority. Use masks and one-hot selections for candidate networks. Mux only fields consumed on the critical path.

Before each added condition, field, register, or mux, determine whether existing invariants already imply it. Prefer an assertion for an upstream contract over duplicated runtime protection when the design assigns that responsibility upstream.

Organize substantial Scala source with the repository's required functional separators. Add concise comments only for cycle contracts, non-obvious invariants, intentional redundancy left for synthesis, and timing-sensitive choices.

## Maintain three documentation layers

Keep ownership explicit:

- Architecture/design documents: maintained by the user; define target semantics.
- Module-local document without `_codex`: maintained by the user; supplies interfaces, local methods, names, and preferred snippets.
- `<SourceBase>_codex.md`: maintained by the agent; records implemented behavior, event priority, assertions, verification, and timing risks.

Update `_codex.md` with every source change. Follow repository line limits, commonly 100 lines per source document. Never use `_codex.md` to override user design.

## Verify and review

Read [verification-review.md](references/verification-review.md). Add focused assertions and directed corner cases, then run Verilator as the default ChiselTest backend. Compilation alone is not verification.

After primary verification, dispatch two independent subagents when the environment supports them:

1. Static-review subagent: inspect source and documents for correctness, redundancy, overprotection, timing paths, dependency chains, assertion quality, and test gaps.
2. Verification subagent: independently run tests, preserve commands, seeds, logs, failures, and concise conclusions.

Give subagents raw paths and acceptance criteria. Do not leak the expected conclusion. Store their short reports in the module test directory using repository naming conventions. If subagents are unavailable, state that explicitly and perform two clearly separated local passes without claiming independence.

Address valid findings, rerun affected tests, and update reports. Do not mark the task complete while required tests fail or sessions remain active.

## Deliver

Report concisely:

- modified files and governing design documents;
- reused reference structures and any new fields;
- event priority, assertions, and deliberately omitted redundant logic;
- timing risks and any remaining dependency chain with location and scale;
- Verilator commands, seeds, cycle counts, results, and log paths;
- `_codex.md`, static-review report, and verification report paths;
- unresolved issues or unverified behavior.
