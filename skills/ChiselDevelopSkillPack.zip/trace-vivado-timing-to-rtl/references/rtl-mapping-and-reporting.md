# RTL Mapping and Timing Report Structure

## Contents

1. Mapping procedure
2. Primitive interpretation
3. Structural opportunity accounting
4. Report template
5. Implementation handoff

## 1. Mapping procedure

For each representative path:

1. Locate the launch register or memory output in current RTL.
2. Locate the destination pin and its exact assignment or inferred memory port.
3. Search every physical net and cell name in generated SystemVerilog.
4. Trace input pins and LUT `INIT` when a single-cell Boolean claim is needed.
5. Read Chisel source, parameters, and design documentation for event and cycle meaning.
6. Divide the physical chain at natural RTL boundaries.
7. Label each region with confidence: measured, mapped, inferred, or unknown.

Optimized names often inherit unrelated source names after flattening and logic sharing. A cell named after `valid`, `pc`, or `memory0` can implement logic from several source expressions.

## 2. Primitive interpretation

| Primitive | Questions to answer |
|---|---|
| LUT2 to LUT6 | exact INIT, active input pin, packed compares or muxes, removable inputs |
| MUXF7/MUXF8 | candidate width, selector arrival, whether selection can move earlier |
| CARRY4 | add, subtract, equality, age boundary, popcount, or priority structure |
| FDRE/FDSE | D, CE, reset/set, replicated driver, state version |
| RAMB18/RAMB36 | clock-to-output, ADDR, EN, WE, DIN path, read-first/write-first mode |
| LUTRAM/SRL | asynchronous or synchronous read, replicated banks, reset behavior |
| DSP | operation mode, preadder, cascade, input/output register use |
| BUFG/PLL/MMCM | launch/capture clock path only, never mix into data delay |

Pair every cell with the following routed net. A low cell delay followed by a long route is a placement or fanout problem in that physical run. Logic structure can still create the placement pressure.

## 3. Structural opportunity accounting

At a proposed cut point, report:

```text
old cumulative data delay to the next primitive input
cell levels certainly removed
old routes associated with the removed levels
replacement C/Q and route that will still exist
remaining measured suffix
covered path and endpoint counts
other startpoint families that bypass the cut
new D, Q, feedback, CE, reset, and flush paths
```

Example conclusion:

```text
Measured: the old Q-to-cut prefix is 2.680 ns and contains two LUT6 levels.
Guaranteed structural change: two LUT6 levels leave the consumer path.
Unmeasured: the new register Q route and post-route end-to-end gain.
Remaining suffix: 9.155 ns before rerouting.
```

When precomputing only a selector:

```text
selector compare may move to a register D cone
data mux remains on the Q-side data arc
guaranteed removed data levels can be zero
packing, fan-in, and route may still improve
```

## 4. Report template

```markdown
# <Configuration> Vivado timing analysis

## Run identity

| Field | Value |
|---|---|
| Raw run | ... |
| Routed DCP SHA256 | ... |
| Vivado and part | ... |
| CPU clock | ... |
| Source revision | ... |

## Closure and evidence boundary

Setup, hold, constraints, query size, truncation, and missing artifacts.

## Path-family summary

| Family | Count | Data | Logic | Route | Levels | Worst slack |
|---|---:|---:|---:|---:|---:|---:|

## Representative path

Source, destination, requirement, slack, clock skew, uncertainty, and primitive counts.

| Stage | Cell/site | Cell ns | Following route ns | Fanout | Cumulative ns | RTL region | Confidence |
|---:|---|---:|---:|---:|---:|---|---|

## Shared prefix and endpoint tails

State which families share the prefix and where their endpoint-specific tails diverge.

## Candidate coverage

| Candidate | Covered paths | Removed levels | Remaining suffix | New pressure | Contract to prove |
|---|---:|---:|---:|---|---|

## Ranked directions

Measured rationale, source location, expected structural change, and uncertainty.

## Missing queries

Exact DCP and Tcl commands.

## Implementation handoff

Files, cycle contract, assertions, tests, and routed A/B query matrix.
```

## 5. Implementation handoff

The handoff to `optimize-chisel-fpga-timing` must contain:

1. Exact source files and source expressions.
2. Current producer, consumer, register boundary, valid interval, and event type.
3. Primitive levels and routes targeted by the change.
4. Covered and unaffected path families.
5. Remaining suffix after the proposed boundary.
6. New D, Q, feedback, control, and reset paths to measure.
7. Any interface, latency, ordering, forwarding, flush, or hold-semantic risk.
8. Raw report and routed DCP identity.

Do not hand off a guaranteed nanosecond gain. Hand off a structural hypothesis and the evidence needed to accept or reject it.
